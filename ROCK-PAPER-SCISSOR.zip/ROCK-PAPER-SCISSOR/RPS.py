from tkinter import *
from tkinter import messagebox
from PIL import ImageTk,Image
import random


#Creating window design
root=Tk()
root.configure(bg='purple')
root.iconbitmap("C:/Users/user/Dropbox/PC/Desktop/p1p1.ico")
root.title("Rock-Paper-Scissor")
root.resizable(False,True)

msg='Folded_Hand : Rock\nOpen_Hand : Paper\n2finger_Hand : Scissor\n'
msg1='--'*15
msg2='\n[R]ock Vs [S]cissor   (Rock Wins)\n[P]aper Vs [S]cissor  (Scissor Wins)\n[R]ock Vs [P]aper     (Paper Wins)'
messagebox.showinfo('RULES',msg+msg1+msg2)
def clk():
    pn['text']=e.get()
    e.destroy()
    b1['state']=NORMAL
    b2['state']=NORMAL
    b3['state']=NORMAL
    btn.destroy()
    player_label.destroy()
    computer_name.grid(row=1,column=0)

f1=LabelFrame(root,bg='yellow',cursor='dot')
l1=Label(f1,text='Rock-Paper-Scissor',bg='purple',fg='yellow',font=300)
l1.grid()
f1.grid(row=0,column=3,pady=25)
player_label=Label(root,text='Enter you name : ',bg='purple',fg='yellow')
player_label.grid(row=0,column=0)
e=Entry(root,bg='light blue',bd=10)
e.grid(row=0,column=1)
pn=Label(root,text='',bg='purple',fg='yellow',font=50)
pn.grid(row=1,column=6)
btn=Button(root,text='SUBMIT',bg='light blue',foreground='dark green',bd=15,command=clk)
btn.grid(row=1,column=1)
computer_name=Label(root,text='Computer',bg='purple',fg='yellow',font=50)



#images declaration
img1=ImageTk.PhotoImage(Image.open('images/scissor_u.png'))
img2=ImageTk.PhotoImage(Image.open('images/rock_u.png'))
img3=ImageTk.PhotoImage(Image.open('images/paper_u.png'))
img4=ImageTk.PhotoImage(Image.open('images/scissor_c.png'))
img5=ImageTk.PhotoImage(Image.open('images/paper_c.png'))
img6=ImageTk.PhotoImage(Image.open('images/rock_c.png'))
imgvs=ImageTk.PhotoImage(Image.open('images/vs.png'))
computer=ImageTk.PhotoImage(Image.open('images/computer.png'))
user=ImageTk.PhotoImage(Image.open('images/user.png'))

#image insertion
label1=Label(root,image=computer,bg='purple')#.pack()
label1.grid(row=2,column=0)
label12=Label(root,image=imgvs,bg='purple')#.pack()
label12.grid(row=2,column=3)
label2=Label(root,image=user,bg='purple')#.pack()
label2.grid(row=2,column=6)

u_label=Label(root,text='0',bg='purple',fg='yellow',font=100)
u_label.grid(row=2,column=5)
c_label=Label(root,text='0',bg='purple',fg='yellow',font=100)
c_label.grid(row=2,column=1)

def winner(name):
    messagebox.showinfo('WINNER',name)
    messagebox.askyesno('FEEDBACK','Was the Game good ?')

def score(u):
    c=random.choice(['r','p','s'])
    
     #display
    if u=='r':
        label2['image']=img2
    elif u=='p':
        label2['image']=img3
    else:
        label2['image']=img1
    if c=='r':
        label1['image']=img6
    elif c=='p':
        label1['image']=img5
    else:
        label1['image']=img4
    
    #computer generation
    Label(root,text='Computer\'s SCORE',bg='purple',fg='yellow').grid(row=1,column=1)
    Label(root,text=pn['text']+'\'s SCORE',bg='purple',fg='yellow').grid(row=1,column=5)
    
    u_score=int(u_label['text'])
    c_score=int(c_label['text'])

    if ((u=='r') and (c=='s')) or ((u=='p') and (c=='r')) or ((u=='s') and (c=='p')):
        u_score+=1
    if ((u=='r') and (c=='p')) or ((u=='p') and (c=='s')) or((u=='s') and (c=='r')):
        c_score+=1
    if u==c:
        u_score+=1
        c_score+=1 

    u_label['text']=str(u_score)
    c_label['text']=str(c_score)

    #winner checker
    if (u_score>=20) and (c_score<u_score):
        b1['state']=DISABLED
        b2['state']=DISABLED
        b3['state']=DISABLED
        winner(pn['text'])
        root.destroy()
        
    if (c_score>=20) and (u_score<c_score):
        b1['state']=DISABLED
        b2['state']=DISABLED
        b3['state']=DISABLED
        winner('Computer')
        root.destroy()    

#buton insertion
b1=Button(root,text='Rock',bg='purple',fg='yellow',activebackground='dark blue',bd=8,font=15,justify=CENTER,underline=0,state=DISABLED,command=lambda:score('r'))
b1.grid(row=3,column=2)
b2=Button(root,text='Paper',bg='purple',fg='yellow',activebackground='dark blue',bd=8,font=15,justify=CENTER,underline=0,state=DISABLED,command=lambda:score('p'))
b2.grid(row=3,column=3)
b3=Button(root,text='Scissor',bg='purple',fg='yellow',activebackground='dark blue',bd=8,font=15,justify=CENTER,underline=0,state=DISABLED,command=lambda:score('s'))
b3.grid(row=3,column=4)

root.mainloop()
